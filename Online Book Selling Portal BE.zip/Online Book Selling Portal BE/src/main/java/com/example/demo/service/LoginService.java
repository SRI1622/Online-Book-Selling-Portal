// package com.example.demo.service;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;

// import com.example.demo.model.Customer;
// import com.example.demo.repository.CustomerRepository;

// import java.util.*;

// @Service
// public class LoginService {

//     @Autowired
//     private static CustomerRepository customerRepository;

//     // public static Customer GoLogin(String cusName, String password) {

//     //     List<Customer> list=new ArrayList<>();
//     //     for(int i=0;i< list.size();i++){
//     //         Optional<Customer> optionalDetail = customerRepository.findAll();
//     //     }
//     //     return null;
//     // }
    
// }
